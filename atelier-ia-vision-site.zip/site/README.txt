1. Cree un depot PUBLIC GitHub nomme exactement : atelier-ia-vision
2. Mets-y ces fichiers a la racine : index.html + les 2 notebooks .ipynb
3. Settings > Pages > Source : "Deploy from a branch", branche main, dossier / (root)
4. Apres ~1 minute, la page est sur : https://vnullptr.github.io/atelier-ia-vision/
Si tu changes le nom du depot, remplace "atelier-ia-vision" dans index.html (2 liens) et regenere le QR.
